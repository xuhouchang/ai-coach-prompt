# AI Coach Prompt v3.1.2

面向 WorkBuddy / CodeBuddy 兼容宿主的交互式 Prompt 教学 Skill。

## v3.1 安全架构

v3.1 将教学能力与业务执行能力彻底分离：

- Skill 不再拥有通用 `Read`、`Write`、`Bash`、浏览器、消息、任务、Connector 或 Agent 工具。
- 只允许三个专用 MCP 工具：课程资源白名单读取、当前 profile 读取、schema 校验后的 profile patch。
- 待测试 Prompt 经过 `原样捕获 → 学习材料确认 → 分类 → 节点覆盖 → 五维评分`。
- 捕获状态关闭导航、控制词和执行意图解析。
- profile 服务不接受文件路径或 learner ID，数据写入插件私有数据目录。
- 持久化失败时降级为会话状态与恢复胶囊，不申请更宽权限。

## 安装包结构

```text
ai-coach-prompt/
├── .workbuddy-plugin/plugin.json
├── .mcp.json
├── servers/profile-store.mjs
└── skills/ai-coach-prompt/
    ├── SKILL.md
    ├── system_instructions.en.md
    └── ...
```

## 使用

安装插件后，手动调用 `/ai-coach-prompt` 开始课程。该 Skill 设置了 `disable-model-invocation: true`，避免普通业务 Prompt 自动触发教学 Skill。

## 验证

在源码目录运行：

```bash
python3 scripts/validate_skill.py
node tests/test_profile_store.mjs
```

构建安装包：

```bash
python3 scripts/build_workbuddy_installable.py
```


## 交互方式

默认使用 `text_nonblocking`：选择页显示编号文本，用户直接输入数字或对应文字。安装包不授予 `AskUserQuestion`，因此不会主动进入 WorkBuddy 的原生面板等待状态。每次助手输出只包含一个教学页面，随后正常结束回合。

### 从 v3.1.1 升级

1. 停止旧版本正在运行的课程任务。
2. 在 WorkBuddy 中安装 v3.1.2 Plugin zip，覆盖或替换 v3.1.1。
3. 在权限界面确认仅显示三个 `ai-coach-profile` MCP 工具，未显示 `AskUserQuestion`、通用文件、Shell 或 Agent 能力。
4. 新开课程，或使用“继续上次学习”恢复。已有 v2 Profile 会自动补齐非阻塞页面状态字段。
